"use strict";
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "./pages/api/auth/[...nextauth].ts":
/*!*****************************************!*\
  !*** ./pages/api/auth/[...nextauth].ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ "next-auth");
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_providers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers */ "next-auth/providers");
/* harmony import */ var next_auth_providers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers__WEBPACK_IMPORTED_MODULE_1__);


const options = {
  // Configure one or more authentication providers
  providers: [next_auth_providers__WEBPACK_IMPORTED_MODULE_1___default().Okta({
    clientId: process.env.OKTA_CLIENTID,
    clientSecret: process.env.OKTA_CLIENTSECRET,
    domain: process.env.OKTA_DOMAIN,
    protection: ["pkce", "state"]
  }) // ...add more providers here
  ]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((req, res) => next_auth__WEBPACK_IMPORTED_MODULE_0___default()(req, res, options));

/***/ }),

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers":
/*!**************************************!*\
  !*** external "next-auth/providers" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/auth/[...nextauth].ts"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUEsTUFBTUUsT0FBTyxHQUFHO0FBQ2Q7QUFDQUMsRUFBQUEsU0FBUyxFQUFFLENBQ1RGLCtEQUFBLENBQWU7QUFDYkksSUFBQUEsUUFBUSxFQUFFQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsYUFEVDtBQUViQyxJQUFBQSxZQUFZLEVBQUVILE9BQU8sQ0FBQ0MsR0FBUixDQUFZRyxpQkFGYjtBQUdiQyxJQUFBQSxNQUFNLEVBQUVMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxXQUhQO0FBSWJDLElBQUFBLFVBQVUsRUFBQyxDQUFDLE1BQUQsRUFBUSxPQUFSO0FBSkUsR0FBZixDQURTLENBT1Q7QUFQUztBQUZHLENBQWhCO0FBYUEsaUVBQWUsQ0FBQ0MsR0FBRCxFQUFNQyxHQUFOLEtBQWNmLGdEQUFRLENBQUNjLEdBQUQsRUFBTUMsR0FBTixFQUFXYixPQUFYLENBQXJDOzs7Ozs7Ozs7O0FDaEJBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tb3ZpZXMvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzIiwid2VicGFjazovL21vdmllcy9leHRlcm5hbCBcIm5leHQtYXV0aFwiIiwid2VicGFjazovL21vdmllcy9leHRlcm5hbCBcIm5leHQtYXV0aC9wcm92aWRlcnNcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTmV4dEF1dGggZnJvbSAnbmV4dC1hdXRoJ1xyXG5pbXBvcnQgUHJvdmlkZXJzIGZyb20gJ25leHQtYXV0aC9wcm92aWRlcnMnXHJcblxyXG5jb25zdCBvcHRpb25zID0ge1xyXG4gIC8vIENvbmZpZ3VyZSBvbmUgb3IgbW9yZSBhdXRoZW50aWNhdGlvbiBwcm92aWRlcnNcclxuICBwcm92aWRlcnM6IFtcclxuICAgIFByb3ZpZGVycy5Pa3RhKHtcclxuICAgICAgY2xpZW50SWQ6IHByb2Nlc3MuZW52Lk9LVEFfQ0xJRU5USUQsXHJcbiAgICAgIGNsaWVudFNlY3JldDogcHJvY2Vzcy5lbnYuT0tUQV9DTElFTlRTRUNSRVQsXHJcbiAgICAgIGRvbWFpbjogcHJvY2Vzcy5lbnYuT0tUQV9ET01BSU4sXHJcbiAgICAgIHByb3RlY3Rpb246W1wicGtjZVwiLFwic3RhdGVcIixdLFxyXG4gICAgfSksXHJcbiAgICAvLyAuLi5hZGQgbW9yZSBwcm92aWRlcnMgaGVyZVxyXG4gIF1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgKHJlcSwgcmVzKSA9PiBOZXh0QXV0aChyZXEsIHJlcywgb3B0aW9ucykiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0LWF1dGhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC1hdXRoL3Byb3ZpZGVyc1wiKTsiXSwibmFtZXMiOlsiTmV4dEF1dGgiLCJQcm92aWRlcnMiLCJvcHRpb25zIiwicHJvdmlkZXJzIiwiT2t0YSIsImNsaWVudElkIiwicHJvY2VzcyIsImVudiIsIk9LVEFfQ0xJRU5USUQiLCJjbGllbnRTZWNyZXQiLCJPS1RBX0NMSUVOVFNFQ1JFVCIsImRvbWFpbiIsIk9LVEFfRE9NQUlOIiwicHJvdGVjdGlvbiIsInJlcSIsInJlcyJdLCJzb3VyY2VSb290IjoiIn0=